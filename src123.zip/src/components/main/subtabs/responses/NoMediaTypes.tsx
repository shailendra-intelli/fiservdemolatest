// @ts-nocheck
import React from "react";
import { Card, Button } from "intelli-ui-components-library";
import { AddIcon } from "../../../../assets/icons";
import { useAppDispatch, useAppSelector } from "../../../../store/hooks";
import {
  updatePath,
  intitialStatePathMethod,
  DEFAULT_Response_OBJ,
} from "../../mainTabsSlice";

const NoMediaTypes = ({ pathName, methodName, onClick }: any) => {
  const paths = useAppSelector((state) => state.main.paths);
  const responseState = useAppSelector((state) => state.main.response);
  const dispatch = useAppDispatch();
  return (
    <Card
      round="round"
      style={{
        margin: "10px",
      }}
    >
      <Card.CardHeader
        title="There are no media-types defined (they are optional)."
        divider="dark"
      />
      <Card.CardAction>
        <div onClick={onClick}>
          <Button
            size="md"
            variant="contained"
            round="round"
            color="primary"
            onClick={() => {
              const responses = paths[pathName]?.[methodName]?.responses || {};
              const newKey = Object.keys(responses).length.toString();
              dispatch(
                updatePath({
                  pathName,
                  methodName,
                  methodKey: "responses",
                  data: {
                    ...responses,
                    [newKey]: DEFAULT_Response_OBJ,
                  },
                })
              );
            }}
            className="mb-2"
            icon={<AddIcon />}
          >
            <span>
              <AddIcon />
            </span>
            Create MediaType
          </Button>
        </div>
      </Card.CardAction>
    </Card>
  );
};

export default NoMediaTypes;
